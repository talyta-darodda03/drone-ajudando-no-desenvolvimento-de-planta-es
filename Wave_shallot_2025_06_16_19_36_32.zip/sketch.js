let drone;
let plants = [];
let pests = [];
let bullets = [];

function setup() {
  createCanvas(800, 400);
  drone = new Drone();

  // Cria plantas
  for (let x = 50; x < width; x += 60) {
    plants.push(new Plant(x, height - 60));
  }

  // Cria pragas aleatórias em algumas plantas
  for (let i = 0; i < 5; i++) {
    let plantIndex = floor(random(plants.length));
    pests.push(new Pest(plants[plantIndex]));
  }
}

function draw() {
  background(150, 220, 150);
  drawField();

  // Atualiza e mostra plantas
  for (let plant of plants) {
    // Se tem praga, planta cresce mais devagar
    if (plant.hasPest()) {
      plant.grow(0.002);
    } else {
      // Se drone perto, crescimento acelerado
      if (dist(drone.x, drone.y, plant.x, plant.y) < 100) {
        plant.grow(0.05);
      } else {
        plant.grow(0.01);
      }
    }
    plant.display();
  }

  // Atualiza e mostra pragas
  for (let pest of pests) {
    pest.update();
    pest.display();
  }

  // Atualiza e mostra balas (veneno)
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].update();
    bullets[i].display();

    // Checa colisão com pragas
    for (let j = pests.length - 1; j >= 0; j--) {
      if (bullets[i].hits(pests[j])) {
        pests[j].remove();
        bullets.splice(i, 1);
        break;
      }
    }

    // Remove bala se sair da tela
    if (bullets[i] && bullets[i].offscreen()) {
      bullets.splice(i, 1);
    }
  }

  // Atualiza e mostra drone
  drone.update();
  drone.display();

  fill(0);
  textSize(18);
  text("Use SETAS para mover, ESPAÇO para spray", 10, 20);
}

function drawField() {
  fill(100, 180, 100);
  rect(0, height - 50, width, 50);
  stroke(50, 120, 50);
  for (let x = 0; x < width; x += 20) {
    line(x, height - 50, x, height - 20);
  }
  noStroke();
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) drone.move(-1);
  if (keyCode === RIGHT_ARROW) drone.move(1);
  if (key === ' ') drone.spray();
}

class Drone {
  constructor() {
    this.x = width / 2;
    this.y = 100;
    this.speed = 5;
  }

  move(dir) {
    this.x += dir * this.speed;
    this.x = constrain(this.x, 20, width - 20);
  }

  spray() {
    bullets.push(new Bullet(this.x, this.y + 20)); // inicia logo abaixo do drone
  }

  update() {
    // drone não se move sozinho aqui, só com setas
  }

  display() {
    push();
    translate(this.x, this.y);
    fill(0, 100, 255);
    ellipse(0, 0, 60, 20);
    fill(100);
    ellipse(-20, -10, 30, 10);
    ellipse(20, -10, 30, 10);
    ellipse(-20, 10, 30, 10);
    ellipse(20, 10, 30, 10);
    pop();
  }
}

class Plant {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.height = 10;
    this.maxHeight = 60;
    this.pests = [];
  }

  grow(amount) {
    this.height += amount;
    if (this.height > this.maxHeight) this.height = this.maxHeight;
    if (this.height < 10) this.height = 10;
  }

  display() {
    fill(34, 139, 34);
    rect(this.x - 5, this.y, 10, -this.height);
    fill(50, 205, 50);
    ellipse(this.x, this.y - this.height, 15, 10);
  }

  hasPest() {
    return this.pests.length > 0;
  }

  addPest(pest) {
    this.pests.push(pest);
  }

  removePest(pest) {
    let idx = this.pests.indexOf(pest);
    if (idx > -1) this.pests.splice(idx, 1);
  }
}

class Pest {
  constructor(plant) {
    this.plant = plant;
    this.x = plant.x + random(-10, 10);
    this.y = plant.y - plant.height - 5;
    this.size = 15;
    this.alive = true;
    plant.addPest(this);
  }

  update() {
    if (!this.alive) return;

    // Praga tenta fugir do drone
    let dx = this.x - drone.x;
    let dy = this.y - drone.y;
    let distToDrone = dist(this.x, this.y, drone.x, drone.y);
    if (distToDrone < 100) {
      let angle = atan2(dy, dx);
      this.x += cos(angle) * 2;
      this.y += sin(angle) * 2;

      // Limita a praga a ficar perto da planta
      this.x = constrain(this.x, this.plant.x - 30, this.plant.x + 30);
      this.y = constrain(this.y, this.plant.y - this.plant.height - 20, this.plant.y - 5);
    } else {
      // Pequeno movimento natural
      this.x += random(-0.5, 0.5);
      this.y += random(-0.2, 0.2);
    }
  }

  display() {
    if (!this.alive) return;
    fill(139, 69, 19);
    ellipse(this.x, this.y, this.size);
  }

  remove() {
    this.alive = false;
    this.plant.removePest(this);
    // Remove da lista global de pragas
    let idx = pests.indexOf(this);
    if (idx > -1) pests.splice(idx, 1);
  }
}

class Bullet {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = 7;
    this.size = 8;
  }

  update() {
    this.y += this.speed;  // Agora o veneno desce
  }

  display() {
    fill(0, 200, 255);
    ellipse(this.x, this.y, this.size);
  }

  hits(pest) {
    let d = dist(this.x, this.y, pest.x, pest.y);
    return d < (this.size / 2 + pest.size / 2);
  }

  offscreen() {
    return this.y > height;
  }
}